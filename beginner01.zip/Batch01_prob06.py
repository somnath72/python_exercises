##	LOCATION:	cd C:\Courses\Python\beginner
##	TO EXECUTE:	python Batch01_prob06.py
##	OBJECTIVE:	Write a program that reads two files and created a new file by concatenating the two
##	+++++++++++++++++++++++++++
##	Created By:	Somnath Banerjee
##	Created On:	20/AUG/2019
##	+++++++++++++++++++++++++++
import os.path
from os import path

def main():
	inputFiles = []
	outputFile = "C:\\Courses\\Python\\beginner\\output.txt"
	
	inputFiles.append(input('\nEnter the name of the first file: '))
	inputFiles.append(input('\nEnter the name of the second file: '))
	
	#print(str(os.path.isfile(inputFiles[0])))
	#print(str(os.path.isfile(inputFiles[1])))
	
	## Check if the file exist
	if not path.exists(inputFiles[0]):
		print("File {} does not exist".format(inputFiles[0]))
	elif not path.exists(inputFiles[1]):
		print("File {} does not exist".format(inputFiles[1]))
	else:
		with open(outputFile, 'w') as outfile:
			for fname in inputFiles:
				with open(fname, "r") as infile:
					for line in infile:	## Line by line copy will ensure that big files are are not failing due to total filr read in the memory
						outfile.write(line)
		print("\nFiles '{}' and '{}' are copied to '{}'".format(inputFiles[0], inputFiles[1], outputFile))

if __name__ == '__main__':
	main()
