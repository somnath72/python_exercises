##	LOCATION:	cd C:\Courses\Python\beginner
##	TO EXECUTE:	python Batch01_prob01.py
##	OBJECTIVE:	Write a program to concatenate two dictionaries in to one
##	+++++++++++++++++++++++++++
##	Created By:	Somnath Banerjee
##	Created On:	19/AUG/2019
##	+++++++++++++++++++++++++++
def returnConcatenatedDict(d1, d2):
	d1.update(d2)
	return d1


def main():
	dict1 = {'a': 1, 'b':2, 'c':3}
	dict2 = {'c': 3, 'd':4, 'e':5, 'b': 99, 'f':6}
	
	print(dict1)
	print(dict2)
	
	##	Note: Key 'b' has different value in second dictionary with its order also not same and key 'c' has same values in the 2 lists
	##	'b' gets the latest one (value from 2nd list
	##	'c' is not duplicated
	concatenatedDict = returnConcatenatedDict(dict1, dict2)
	print("Concatenated dictionary {}".format(concatenatedDict))

if __name__ == '__main__':
	main()
