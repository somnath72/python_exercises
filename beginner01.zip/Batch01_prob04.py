##	LOCATION:	cd C:\Courses\Python\beginner
##	TO EXECUTE:	python Batch01_prob04.py
##	OBJECTIVE:	Write a program that takes a string of 5 lines and returns a dictionary of words and their counts
##	+++++++++++++++++++++++++++
##	Created By:	Somnath Banerjee
##	Created On:	20/AUG/2019
##	+++++++++++++++++++++++++++

def wordCountDict(strLines):
	wc_dict = dict()
	words = strLines.split()
	for word in words:
		if word in wc_dict:
			wc_dict[word] += 1
		else:
			wc_dict[word] = 1
	return wc_dict


def main():
	lines = ""
	print("\nPlease enter text in 5 lines...")
	for i in range(5):
		lines+=input()+"\n"
	
	d = wordCountDict(lines)
	print("Lines Input {}".format(lines))
	print(d)

if __name__ == '__main__':
	main()
