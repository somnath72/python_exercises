##	LOCATION:	cd C:\Courses\Python\beginner
##	TO EXECUTE:	python Batch01_prob03.py
##	OBJECTIVE:	Write a program that prints out sum and product of all items in a dictionary
##	+++++++++++++++++++++++++++
##	Created By:	Somnath Banerjee
##	Created On:	19/AUG/2019
##	+++++++++++++++++++++++++++
def returnSumProduct(dict):
	sum = 0
	prod = 1
	for i in dict.values():
		sum = sum + i
		prod = prod * i
	return sum, prod


def main():
	dict = {'a': 2, 'b':4, 'c':6}
	s, p = returnSumProduct(dict)
	print("Print the SUM and PRODUCT of all the numbers in the dictionary {}".format(dict))
	print("Sum : {}\nProduct: {}".format(s, p))

if __name__ == '__main__':
	main()
