##	LOCATION:	cd C:\Courses\Python\beginner
##	TO EXECUTE:	python Batch01_prob07.py
##	OBJECTIVE:	Write a program that takes string input from user and writes back to an existing file by appending to it
##	+++++++++++++++++++++++++++
##	Created By:	Somnath Banerjee
##	Created On:	20/AUG/2019
##	+++++++++++++++++++++++++++

def main():
	lines = ""
	outputFile = "C:\\Courses\\Python\\beginner\\output.txt"
	
	with open(outputFile, 'a+') as outfile:	## Either creat the file or append to it
		print("\nPlease enter text in the following lines... type the character X {upper case ex} to indicate end of input...")
		while True:
			line = input()
			if line == "X":	## The letter X will NOT be wriitten in the file
				break
			else:
				outfile.write(line+"\n")
	
	print("\nLines written to file '{}'\nTo see the contents:- type {}".format(outputFile, outputFile))

if __name__ == '__main__':
	main()
