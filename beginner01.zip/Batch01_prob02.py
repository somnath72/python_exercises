##	LOCATION:	cd C:\Courses\Python\beginner
##	TO EXECUTE:	python Batch01_prob02.py
##	OBJECTIVE:	Write  a program that takes two lists and hashes/maps to a dictionary
##	+++++++++++++++++++++++++++
##	Created By:	Somnath Banerjee
##	Created On:	20/AUG/2019
##	+++++++++++++++++++++++++++

def main():
	list1 = ['a', 'b', 'c', 'd']
	list2 = [1, 2, 3, 4]
	dictm = dict(zip(list1, list2))
	
	print(list1)
	print(list2)
	print("Mapped to dictionary {}".format(dictm))

if __name__ == '__main__':
	main()
