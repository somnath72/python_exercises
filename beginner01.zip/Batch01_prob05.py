##	LOCATION:	cd C:\Courses\Python\beginner
##	TO EXECUTE:	python Batch01_prob05.py
##	OBJECTIVE:	Write a file reader program that prints out the content to console along with the number of lines and words and blanks in the file
##	+++++++++++++++++++++++++++
##	Created By:	Somnath Banerjee
##	Created On:	20/AUG/2019
##	+++++++++++++++++++++++++++

def main():
	fileName = input('\nEnter file name here to analize with path:: ')
	try:
		with open(fileName, 'r') as f:
			data = f.read()
			line = data.splitlines()
			words = data.split()
			spaces = data.split(" ")
		print("\nNumber of lines {}\nNumber of Words {}\nNumber of Spaces {}".format(len(line), len(words), len(spaces)))
	except FileNotFoundError:
		print("Wrong file name or file path or not in the right case {file name is case sensitive}")
	else:
		print("--END--")

if __name__ == '__main__':
	main()
