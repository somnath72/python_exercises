##	LOCATION:	cd C:\Courses\Python\beginner
##	TO EXECUTE:	python Batch01_prob08.py
##	OBJECTIVE:	Read a file and write back in reverse order of the text (last line comes first and then "hello" becomes "Olleh") with capitalizing all the first character of every word
##	+++++++++++++++++++++++++++
##	Created By:	Somnath Banerjee
##	Created On:	20/AUG/2019
##	+++++++++++++++++++++++++++
import sys
import os.path
from os import path

def main():
	inputFiles = []
	outputFile = "C:\\Courses\\Python\\beginner\\output.txt"
	
	inputFile = input('\nEnter the name of the first file: ')
	newName = os.getcwd() + "\\" + inputFile
	print(newName)
	
	## Check if the file exist
	if not path.exists(inputFile):
		print("File {} does not exist".format(inputFile))
	elif (inputFile == outputFile) or (newName == outputFile):
		print("Input '{}' and output files '{}' are same - cannot read and write to the same file".format(newName, outputFile))
	else:
		with open(outputFile, 'w') as outfile:
			with open(inputFile, "r") as infile:
				for line in reversed(list(infile)):		## reverse the order of reading the file
					outfile.write(str(line)[::-1].title())	## reverse the string and then capitalise the first letter of the reversed words
		print("\nFiles '{}'  copied to '{}'\nTo view, copy and paste the command: type {}".format(inputFile, outputFile, outputFile))

if __name__ == '__main__':
	main()
